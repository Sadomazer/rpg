class ClientGame {
    constructor(cfg) {
        Object.assign(this, {
            cfg,
        });

        this.engine = this.createEngine();
    }

    createEngine() {
        return new ClientEngine(document.getElementById(this.cfg.tagId));
    }

    static init(cfg) {
        if(!ClientGame.game) {
            ClientGame.game = new ClientGame(cfg);
        }
    }
}

export default ClientGame;